<!DOCTYPE html>
<html lang="en">
<head>
    <title>Forgot Password</title>
</head>
<body>
    <h2>Forgot Password</h2>
    <form method="POST" action="reset email.php">
        <label for="email">Email</label><br>
        <input type="email" id="email" name="email" required><br>
        <button type="submit">Submit</button>
    </form>
</body>
</html>
