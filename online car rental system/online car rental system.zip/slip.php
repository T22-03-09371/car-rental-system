<!DOCTYPE html>
<html lang="en">
<head>
    <title>online car rental system</title>
    <link rel="stylesheet" href="punch.css">
</head>
<body>
    <div>
    <h1>welcom to car rental system</h1>
    <p>your successful registered</p>
    <h3>click to here!!!! <a href="login.php">log in</a></h3>
    </div>
 
</body>
</html>