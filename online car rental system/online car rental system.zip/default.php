<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="pp.css">
    <title>Welcome to the Admin Dashboard</title>
    <style>
        /* Add CSS styles for the default content as needed */
        .default-content {
            padding: 20px;
        }

        h2 {
            font-size: 24px;
            text-align: center;
            background:  rgb(94, 150, 150);
        }

        p {
            font-size: 16px;
            line-height: 1.5;
        }
    </style>
</head>
<body>
    <div >
        <h2>Welcome to the employee Dashboard</h2>
    </div>
</body>
</html>
